<!-- 662061000 Nurhayati Aleemamah. -->

<?php
session_start();
require_once __DIR__ . '/../includes/db_connect.php';
$conn->set_charset('utf8mb4');
$conn->select_db('cat_hotel');

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}
$user_id = intval($_SESSION['user_id']);
$user_name = $_SESSION['name'] ?? 'ผู้ใช้';

// ดึงสถิติรวม
$stats_query = $conn->prepare("
    SELECT 
        COUNT(*) as total_bookings,
        SUM(CASE WHEN status = 'Pending' THEN 1 ELSE 0 END) as pending_count,
        SUM(CASE WHEN status = 'Confirmed' THEN 1 ELSE 0 END) as confirmed_count,
        SUM(CASE WHEN status = 'Occupied' THEN 1 ELSE 0 END) as occupied_count
    FROM bookings WHERE user_id = ?
");
$stats_query->bind_param("i", $user_id);
$stats_query->execute();
$stats = $stats_query->get_result()->fetch_assoc();
$stats_query->close();

// ดึงจำนวนแมวทั้งหมด
$cats_count = $conn->query("SELECT COUNT(*) as count FROM cats WHERE user_id = $user_id")->fetch_assoc()['count'];

// ดึงการจองที่ใกล้วันรับ (0-3 วัน)
$notify_stmt = $conn->prepare("
    SELECT b.booking_id, r.type AS room_name, b.end_date, b.status,
           DATEDIFF(b.end_date, NOW()) as days_left
    FROM bookings b
    JOIN rooms r ON b.rooms_id = r.rooms_id
    WHERE b.user_id = ?
    AND b.status IN ('Pending', 'Confirmed', 'Occupied')
    AND DATEDIFF(b.end_date, NOW()) BETWEEN 0 AND 3
    ORDER BY b.end_date ASC
");
$notify_stmt->bind_param("i", $user_id);
$notify_stmt->execute();
$notifications = $notify_stmt->get_result();
$notify_stmt->close();

// ดึงรายการจองทั้งหมดพร้อมรายละเอียดแมว
$bookings_stmt = $conn->prepare("
    SELECT b.booking_id, b.start_date, b.end_date, b.booking_type, 
           b.status, b.total_price, r.type AS room_name, r.rooms_id,
           GROUP_CONCAT(c.name SEPARATOR ', ') as cat_names,
           COUNT(DISTINCT bc.cat_id) as cat_count
    FROM bookings b
    JOIN rooms r ON b.rooms_id = r.rooms_id
    LEFT JOIN bookings_cats bc ON b.booking_id = bc.booking_id
    LEFT JOIN cats c ON bc.cat_id = c.cat_id
    WHERE b.user_id = ?
    GROUP BY b.booking_id
    ORDER BY b.start_date DESC
    LIMIT 20
");
$bookings_stmt->bind_param("i", $user_id);
$bookings_stmt->execute();
$bookings = $bookings_stmt->get_result();
$bookings_stmt->close();

// ฟังก์ชันแสดงสถานะ
function getStatusBadge($status)
{
    $badges = [
        'Pending' => ['class' => 'status-pending', 'text' => 'รอชำระเงิน'],
        'Confirmed' => ['class' => 'status-confirmed', 'text' => 'ยืนยันแล้ว'],
        'Occupied' => ['class' => 'status-occupied', 'text' => 'กำลังพัก'],
        'Completed' => ['class' => 'status-completed', 'text' => 'เสร็จสิ้น'],
        'Cancelled' => ['class' => 'status-cancelled', 'text' => 'ยกเลิกแล้ว']
    ];
    $badge = $badges[$status] ?? ['class' => 'status-default', 'text' => $status];
    return "<span class='status-badge {$badge['class']}'>{$badge['text']}</span>";
}
?>
<!DOCTYPE html>
<html lang="th">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>แดชบอร์ด - Cat Hotel</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/dashboard.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Bai+Jamjuree:wght@300;400;500;600&family=Cormorant+Garamond:wght@400;500;600;700&display=swap"
        rel="stylesheet">

    <style>
        * {
            font-family: 'Bai Jamjuree', 'Cormorant Garamond', serif;
        }
    </style>
</head>

<body>
    <div class="container section">
        <!-- Header -->
        <div class="dashboard-header">
            <div class="header-content">
                <div>
                    <h1 class="welcome-text">สวัสดี, <?= htmlspecialchars($user_name) ?> 🐱</h1>
                    <p class="subtitle">ยินดีต้อนรับสู่แดชบอร์ดของคุณ</p>
                </div>
                <div class="header-actions">
                    <a href="../index.php" class="btn primary">หน้าหลัก</a>
                    <a href="../logout.php" class="btn">ออกจากระบบ</a>
                </div>
            </div>
        </div>

        <!-- Stats Cards -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon">📊</div>
                <div class="stat-info">
                    <div class="stat-value"><?= $stats['total_bookings'] ?></div>
                    <div class="stat-label">การจองทั้งหมด</div>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-icon">⏳</div>
                <div class="stat-info">
                    <div class="stat-value"><?= $stats['pending_count'] ?></div>
                    <div class="stat-label">รอชำระเงิน</div>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-icon">✅</div>
                <div class="stat-info">
                    <div class="stat-value"><?= $stats['confirmed_count'] ?></div>
                    <div class="stat-label">ยืนยันแล้ว</div>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-icon">🐈</div>
                <div class="stat-info">
                    <div class="stat-value"><?= $cats_count ?></div>
                    <div class="stat-label">แมวของฉัน</div>
                </div>
            </div>
        </div>

        <!-- Notifications -->
        <?php if ($notifications->num_rows > 0): ?>
            <div class="notification-section">
                <h3 class="section-title">🔔 แจ้งเตือนใกล้วันรับแมว</h3>
                <div class="notifications">
                    <?php while ($n = $notifications->fetch_assoc()): ?>
                        <div class="notification-item <?= $n['days_left'] == 0 ? 'urgent' : '' ?>">
                            <div class="notification-icon">
                                <?= $n['days_left'] == 0 ? '🚨' : '⏰' ?>
                            </div>
                            <div class="notification-content">
                                <strong>Booking #<?= $n['booking_id'] ?></strong> - <?= htmlspecialchars($n['room_name']) ?>
                                Room
                                <div class="notification-time">
                                    <?php if ($n['days_left'] == 0): ?>
                                        <span class="urgent-text">วันนี้ถึงกำหนดรับแมว!</span>
                                    <?php else: ?>
                                        เหลืออีก <?= $n['days_left'] ?> วัน (<?= date('d/m/Y', strtotime($n['end_date'])) ?>)
                                    <?php endif; ?>
                                </div>
                            </div>
                            <!-- <a href="payment.php?booking_id=<?= $n['booking_id'] ?>" class="btn btn-sm">ดูรายละเอียด</a> -->
                        </div>
                    <?php endwhile; ?>
                </div>
            </div>
        <?php endif; ?>

        <!-- Bookings List -->
        <div class="bookings-section">
            <h3 class="section-title">📋 ประวัติการจองของฉัน</h3>

            <?php if ($bookings->num_rows > 0): ?>
                <div class="bookings-list">
                    <?php while ($row = $bookings->fetch_assoc()):
                        $num_days = max(1, ceil((strtotime($row['end_date']) - strtotime($row['start_date'])) / 86400));
                        $is_actionable = in_array($row['status'], ['Pending', 'Confirmed']);
                        ?>
                        <div class="booking-card">
                            <div class="booking-header">
                                <div class="booking-id">
                                    <span class="id-label">Booking</span>
                                    <span class="id-number">#<?= $row['booking_id'] ?></span>
                                </div>
                                <?= getStatusBadge($row['status']) ?>
                            </div>

                            <div class="booking-body">
                                <div class="booking-info">
                                    <div class="info-row">
                                        <span class="info-icon">🏠</span>
                                        <div class="info-content">
                                            <div class="info-label">ประเภทห้อง</div>
                                            <div class="info-value"><?= htmlspecialchars($row['room_name']) ?> Room</div>
                                        </div>
                                    </div>

                                    <div class="info-row">
                                        <span class="info-icon">🐱</span>
                                        <div class="info-content">
                                            <div class="info-label">แมว (<?= $row['cat_count'] ?> ตัว)</div>
                                            <div class="info-value"><?= htmlspecialchars($row['cat_names'] ?: 'ไม่มีข้อมูล') ?>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="info-row">
                                        <span class="info-icon">📅</span>
                                        <div class="info-content">
                                            <div class="info-label">ระยะเวลา</div>
                                            <div class="info-value">
                                                <?= date('d/m/Y', strtotime($row['start_date'])) ?> -
                                                <?= date('d/m/Y', strtotime($row['end_date'])) ?>
                                                (<?= $num_days ?> วัน)
                                            </div>
                                        </div>
                                    </div>

                                    <div class="info-row">
                                        <span class="info-icon">💰</span>
                                        <div class="info-content">
                                            <div class="info-label">ยอดชำระ</div>
                                            <div class="info-value price"><?= number_format($row['total_price'], 2) ?> บาท</div>
                                        </div>
                                    </div>

                                    <div class="info-row">
                                        <span class="info-icon">📝</span>
                                        <div class="info-content">
                                            <div class="info-label">ประเภท</div>
                                            <div class="info-value">
                                                <?= $row['booking_type'] === 'Daily' ? 'รายวัน' : 'รายชั่วโมง' ?></div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- <div class="booking-actions">
                                <a href="payment.php?booking_id=<?= $row['booking_id'] ?>" class="btn btn-sm info">
                                    ดูรายละเอียด
                                </a> 
                                
                                <?php if ($is_actionable): ?>
                                    <?php if ($row['status'] === 'Pending'): ?>
                                        <a href="payment.php?booking_id=<?= $row['booking_id'] ?>" class="btn btn-sm primary">
                                            ชำระเงิน
                                        </a>
                                    <?php endif; ?>
                                    
                                    <a href="booking.php?cancel=<?= $row['booking_id'] ?>" 
                                       class="btn btn-sm danger"
                                       onclick="return confirm('คุณแน่ใจที่จะยกเลิกการจองนี้?')">
                                        ยกเลิก
                                    </a>
                                <?php endif; ?> 
                            </div> -->
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <div class="empty-icon">😺</div>
                    <h3>ยังไม่มีการจอง</h3>
                    <p>เริ่มต้นจองห้องพักสำหรับน้องแมวของคุณ</p>
                    <a href="rooms.php" class="btn primary">จองห้องเลย</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>

</html>