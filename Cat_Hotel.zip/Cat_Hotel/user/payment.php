<!-- 662061000 Nurhayati Aleemamah. -->

<?php
session_start();
require_once __DIR__ . '/../includes/db_connect.php';

if (!isset($_GET['booking_id']) || !is_numeric($_GET['booking_id'])) {
    die("booking_id ไม่ถูกต้อง");
}
$booking_id = intval($_GET['booking_id']);

$stmt = $conn->prepare("
    SELECT b.*, r.type AS room_type, r.rooms_id
    FROM bookings b 
    JOIN rooms r ON b.rooms_id=r.rooms_id
    WHERE b.booking_id=?
");
$stmt->bind_param("i", $booking_id);
$stmt->execute();
$booking = $stmt->get_result()->fetch_assoc();

if (!$booking) {
    die("ไม่พบการจองนี้");
}

// ดึงข้อมูลแมว + อาหาร
$stmt = $conn->prepare("SELECT c.name, c.gender, c.age, c.breed, c.disease, c.weight, c.allergy, bc.food 
                        FROM bookings_cats bc 
                        JOIN cats c ON bc.cat_id = c.cat_id 
                        WHERE bc.booking_id = ?");
$stmt->bind_param("i", $booking_id);
$stmt->execute();
$cats_res = $stmt->get_result();

if (!$cats_res) {
    die("Error executing query: " . $conn->error);
}

$cat_list = [];
$num_days = 1;
$unique_foods = [];

$start = new DateTime($booking['start_date']);
$end = new DateTime($booking['end_date']);
$interval = $start->diff($end);

// คำนวณชั่วโมง
$total_hours = ($end->getTimestamp() - $start->getTimestamp()) / 3600;
$total_hours = ceil($total_hours); // ปัดชั่วโมงขึ้น

// นับวัน: ถ้าอยู่วันเดียวกันให้นับเป็น 1 วัน
$start_day = $start->format('Y-m-d H:i:s');
$end_day = $end->format('Y-m-d H:i:s');
if ($start_day === $end_day) {
    $num_days = 1; // วันเดียวกัน = 1 วัน
} else {
    $num_days = max($interval->days, 1); // คนละวัน
}

while ($c = $cats_res->fetch_assoc()) {
    $food_price = 0;
    $food_name = trim($c['food'] ?? ''); // เพิ่ม trim เพื่อตัดช่องว่าง

    if ($food_name && $food_name !== "none") {
        // ถ้ายังไม่เคยดึงราคาอาหารนี้มาก่อน ให้ไปดึงจากฐานข้อมูล
        if (!isset($unique_foods[$food_name])) {
            // ลองค้นหาแบบตรงทั้งหมดก่อน
            $food_stmt = $conn->prepare("SELECT foods_name, price FROM foods WHERE TRIM(foods_name) = ?");
            $food_stmt->bind_param("s", $food_name);
            $food_stmt->execute();
            $res = $food_stmt->get_result()->fetch_assoc();
            $food_stmt->close();

            // ถ้าไม่เจอ ให้ลองค้นหาแบบ LIKE (กรณีชื่อถูกตัด)
            if (!$res) {
                $food_stmt = $conn->prepare("SELECT foods_name, price FROM foods WHERE TRIM(foods_name) LIKE CONCAT(?, '%') LIMIT 1");
                $food_stmt->bind_param("s", $food_name);
                $food_stmt->execute();
                $res = $food_stmt->get_result()->fetch_assoc();
                $food_stmt->close();
            }

            $unique_foods[$food_name] = floatval($res['price'] ?? 0);
        }

        // คำนวณราคาอาหารสำหรับแมวตัวนี้
        $food_price = $unique_foods[$food_name] * $num_days;
    }

    $c['food_price'] = $food_price;
    $cat_list[] = $c;
}

$food_total = 0;
foreach ($unique_foods as $price) {
    $food_total += $price * $num_days;
}

$room_price = $booking['total_price'] - $food_total;

// ประมวลผลการชำระเงิน
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $payment_method = $_POST['payment_method'];
    $amount = $booking['total_price'];

    $stmt = $conn->prepare("INSERT INTO payment (booking_id, amount, payment_method, status) VALUES (?, ?, ?, 'Paid')");
    $stmt->bind_param("ids", $booking_id, $amount, $payment_method);
    $stmt->execute();

    $stmt = $conn->prepare("UPDATE bookings SET status='Occupied' WHERE booking_id=?");
    $stmt->bind_param("i", $booking_id);
    $stmt->execute();

    $stmt = $conn->prepare("
        UPDATE rooms 
        SET status='Occupied' 
        WHERE rooms_id = (SELECT rooms_id FROM bookings WHERE booking_id=?)
    ");
    $stmt->bind_param("i", $booking_id);
    $stmt->execute();

    echo "<script>alert('ชำระเงินเรียบร้อย! สถานะห้องและการจองถูกอัปเดตแล้ว'); window.location.href='dashboard.php';</script>";
    exit();
}
?>
<!DOCTYPE html>
<html lang="th">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>ยืนยันการชำระเงิน</title>
    <link rel="stylesheet" href="../assets/css/payment.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Bai+Jamjuree:wght@300;400;500;600&family=Cormorant+Garamond:wght@400;500;600;700&display=swap"
        rel="stylesheet">

</head>

<body>
    <div class="payment-container">
        <div class="payment-header">
            <h2>ยืนยันการชำระเงิน</h2>
            <p style="margin: 0;">หมายเลขการจอง: #<?php echo $booking_id; ?></p>
        </div>

        <div class="booking-summary">
            <h3 style="margin-top: 0; color: var(--text);">สรุปการจอง</h3>
            <div class="summary-row">
                <span class="summary-label">ประเภทห้อง:</span>
                <span class="summary-value"><?php echo htmlspecialchars($booking['room_type']); ?> Room</span>
            </div>
            <div class="summary-row">
                <span class="summary-label">ประเภทการจอง:</span>
                <span
                    class="summary-value"><?php echo $booking['booking_type'] === 'Daily' ? 'รายวัน' : 'รายชั่วโมง'; ?></span>
            </div>

            <!-- โจทย์ที่ต้องอาจารย์ต้องการ -->
            <div class="summary-row">
                <span class="summary-label">ราคาห้อง:</span>
                <span class="summary-label"><?php echo number_format(($room_price / $num_days), 2); ?> บาท</span>
            </div>

            <div class="summary-row">
                <span class="summary-label">วันที่เข้าพัก:</span>
                <span
                    class="summary-value"><?php echo (new DateTime($booking['start_date']))->format('d/m/Y H:i'); ?></span>
            </div>
            <div class="summary-row">
                <span class="summary-label">วันที่คืนห้อง:</span>
                <span
                    class="summary-value"><?php echo (new DateTime($booking['end_date']))->format('d/m/Y H:i'); ?></span>
            </div>
            <div class="summary-row">
                <span class="summary-label">ระยะเวลาพัก:</span>
                <span class="summary-value">
                    <?php echo ($booking['booking_type'] === 'Hourly') ? $total_hours . ' ชั่วโมง' : $num_days . ' วัน'; ?>
                </span>
            </div>
            <div class="summary-row">
                <span class="summary-label">จำนวนแมว:</span>
                <span class="summary-value"><?php echo count($cat_list); ?> ตัว</span>
            </div>
        </div>

        <?php if (count($cat_list) > 0): ?>
            <div class="cat-section">
                <h3 style="margin-top: 0; color: var(--text);">รายละเอียดแมว</h3>
                <?php foreach ($cat_list as $index => $cat): ?>
                    <div class="cat-item">
                        <h4>แมวตัวที่ <?php echo ($index + 1); ?>: <?php echo htmlspecialchars($cat['name']); ?></h4>
                        <div class="cat-details">
                            <div class="cat-detail-item">
                                <span class="detail-label">เพศ:</span>
                                <span><?php echo $cat['gender'] === 'Male' ? 'ผู้' : 'เมีย'; ?></span>
                            </div>
                            <div class="cat-detail-item">
                                <span class="detail-label">อายุ:</span>
                                <span><?php echo $cat['age']; ?> ปี</span>
                            </div>
                            <div class="cat-detail-item">
                                <span class="detail-label">พันธุ์:</span>
                                <span><?php echo htmlspecialchars($cat['breed']); ?></span>
                            </div>
                            <div class="cat-detail-item">
                                <span class="detail-label">น้ำหนัก:</span>
                                <span><?php echo $cat['weight']; ?> กก.</span>
                            </div>
                            <div class="cat-detail-item">
                                <span class="detail-label">โรคประจำตัว:</span>
                                <span><?php echo $cat['disease'] ?: '-'; ?></span>
                            </div>
                            <div class="cat-detail-item">
                                <span class="detail-label">อาหารที่แพ้:</span>
                                <span><?php echo $cat['allergy'] ?: '-'; ?></span>
                            </div>
                        </div>
                        <?php if ($cat['food'] !== "none" && $cat['food']): ?>
                            <div class="food-info">
                                <strong>อาหารเสริม: <?php echo htmlspecialchars($cat['food']); ?></strong>
                                <span><?php echo number_format($cat['food_price'], 2); ?> บาท</span>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <div class="price-summary">
            <h3 style="margin: 0 0 16px; color: var(--text);">สรุปยอดชำระ</h3>
            <div class="price-row">
                <span>ค่าห้องพัก</span>
                <span><?php echo number_format($room_price, 2); ?> บาท</span>
            </div>
            <div class="price-row">
                <span>ค่าอาหารเสริม</span>
                <span><?php echo number_format($food_total, 2); ?> บาท</span>
            </div>
            <div class="price-row total">
                <span>ยอดชำระทั้งหมด</span>
                <span><?php echo number_format($booking['total_price'], 2); ?> บาท</span>
            </div>
        </div>

        <form method="POST" class="payment-form">
            <h3 style="margin-top: 0; color: var(--text);">ชำระเงิน</h3>
            <div class="form-group">
                <label for="payment_method">เลือกวิธีชำระเงิน</label>
                <select name="payment_method" id="payment_method" required>
                    <option value="">-- เลือกวิธีชำระเงิน --</option>
                    <option value="Credit Card">Credit Card</option>
                    <option value="Bank Transfer">Bank Transfer</option>
                    <option value="Cash">Cash</option>

                </select>
            </div>

            <div class="button-group">
                <button type="button" class="btn-edit"
                    onclick="window.location.href='booking.php?room_id=<?php echo $booking['rooms_id']; ?>&edit=<?php echo $booking_id; ?>'">
                    แก้ไขการจอง
                </button>
                <button type="submit" class="btn-pay">
                    ยืนยันการชำระเงิน
                </button>
            </div>
        </form>

        <a href="index.php" class="btn-back">กลับไปหน้าหลัก</a>
    </div>
</body>

</html>