<!-- 662061000 Nurhayati Aleemamah. -->

<?php
session_start();
require_once __DIR__ . '/../includes/db_connect.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

$error = '';

// ถ้ามี ID แสดงว่าเป็นการแก้ไข
$edit_mode = false;
$food = null;

if (isset($_GET['id'])) {
    $edit_mode = true;
    $food_id = intval($_GET['id']);
    $stmt = $conn->prepare("SELECT * FROM foods WHERE foods_id = ?");
    $stmt->bind_param("i", $food_id);
    $stmt->execute();
    $food = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$food) {
        header("Location: admin.php?tab=foods");
        exit();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $conn->real_escape_string($_POST['foods_name']);
    $price = floatval($_POST['price']);

    if (empty($name)) {
        $error = "กรุณาระบุชื่ออาหาร";
    } elseif ($price <= 0) {
        $error = "กรุณาระบุราคาที่ถูกต้อง";
    } else {
        if ($edit_mode) {
            // อัปเดตข้อมูล
            if ($conn->query("UPDATE foods SET foods_name='$name', price=$price WHERE foods_id=$food_id")) {
                header("Location: admin.php?tab=foods&success=updated");
                exit();
            } else {
                $error = "เกิดข้อผิดพลาด: " . $conn->error;
            }
        } else {
            // เพิ่มข้อมูลใหม่
            if ($conn->query("INSERT INTO foods (foods_name, price) VALUES ('$name', $price)")) {
                header("Location: admin.php?tab=foods&success=added");
                exit();
            } else {
                $error = "เกิดข้อผิดพลาด: " . $conn->error;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="th">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $edit_mode ? 'แก้ไขอาหาร' : 'เพิ่มอาหารใหม่' ?> - Cat Hotel</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Bai+Jamjuree:wght@300;400;500;600;700;800;900&family=Cormorant+Garamond:wght@400;500;600;700&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/food_form.css">
</head>

<body>
    <div class="food-form-container">
        <!-- Back Button -->
        <div class="back-section">
            <a href="admin.php?tab=foods" class="btn-back">
                <span class="icon">←</span>
                <span>กลับไปหน้าอาหาร</span>
            </a>
        </div>

        <!-- Page Header -->
        <div class="page-header">
            <div class="header-icon"><?= $edit_mode ? '✏️' : '🍽️' ?></div>
            <div class="header-content">
                <h1><?= $edit_mode ? 'แก้ไขข้อมูลอาหาร' : 'เพิ่มอาหารใหม่' ?></h1>
                <p><?= $edit_mode ? 'อัปเดตข้อมูลอาหาร #' . $food_id : 'เพิ่มรายการอาหารแมวใหม่เข้าสู่ระบบ' ?></p>
            </div>
            <div class="header-decoration">😺</div>
        </div>

        <!-- Error Alert -->
        <?php if ($error): ?>
            <div class="alert alert-error">
                <span class="alert-icon">⚠️</span>
                <div class="alert-content">
                    <strong>เกิดข้อผิดพลาด!</strong>
                    <p><?= $error ?></p>
                </div>
            </div>
        <?php endif; ?>

        <!-- Main Form -->
        <div class="form-card">
            <form method="POST">
                <!-- Food Information Section -->
                <div class="form-section">
                    <div class="section-title">
                        <span class="title-icon">🐱</span>
                        <h2>ข้อมูลอาหารแมว</h2>
                    </div>

                    <div class="form-group highlight">
                        <label for="foods_name">
                            <span class="label-icon">🏷️</span>
                            <span class="label-text">ชื่อรายการอาหาร</span>
                            <span class="required">*</span>
                        </label>
                        <input type="text" id="foods_name" name="foods_name"
                            placeholder="เช่น อาหารแมวพรีเมี่ยม Buzz, Royal Canin, Whiskas"
                            value="<?= $edit_mode ? htmlspecialchars($food['foods_name']) : '' ?>" required>
                        <small class="help-text">ชื่อเต็มของอาหารแมวหรือแบรนด์</small>
                    </div>

                    <div class="form-group price-group">
                        <label for="price">
                            <span class="label-icon">💰</span>
                            <span class="label-text">ราคาต่อวัน</span>
                            <span class="required">*</span>
                        </label>
                        <div class="input-with-unit">
                            <input type="number" id="price" name="price" step="0.01" min="0" placeholder="0.00"
                                value="<?= $edit_mode ? $food['price'] : '' ?>" required>
                            <span class="unit">บาท/วัน</span>
                        </div>
                        <small class="help-text">ราคาอาหารต่อวันต่อตัว</small>
                    </div>
                </div>

                <!-- Form Actions -->
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">
                        <span class="btn-icon"><?= $edit_mode ? '💾' : '➕' ?></span>
                        <span><?= $edit_mode ? 'บันทึกการแก้ไข' : 'เพิ่มอาหาร' ?></span>
                    </button>
                    <a href="admin.php?tab=foods" class="btn btn-secondary">
                        <span class="btn-icon">❌</span>
                        <span>ยกเลิก</span>
                    </a>
                </div>
            </form>
        </div>

        <!-- Info Box -->
        <div class="info-box">
            <div class="info-icon">💡</div>
            <div class="info-content">
                <h3>คำแนะนำ</h3>
                <ul>
                    <li><strong>ชื่ออาหาร:</strong> ใส่ชื่อที่ชัดเจนและครบถ้วน เช่น ชื่อแบรนด์และรุ่น</li>
                    <li><strong>ราคา:</strong> ระบุราคาเป็นบาทต่อวันต่อตัว สามารถมีทศนิยมได้</li>
                    <li><strong>ตัวอย่าง:</strong> "Royal Canin Persian Adult 2kg" ราคา 120.00 บาท/วัน</li>
                    <li><strong>หมายเหตุ:</strong> ราคานี้จะถูกคิดเมื่อลูกค้าเลือกอาหารเสริม</li>
                </ul>
            </div>
        </div>

        <!-- Quick Tips -->
        <div class="tips-grid">
            <div class="tip-card">
                <div class="tip-icon">🎯</div>
                <h4>ตั้งชื่อให้ชัดเจน</h4>
                <p>ใช้ชื่อที่ลูกค้าเข้าใจง่าย ระบุแบรนด์และขนาด</p>
            </div>

            <div class="tip-card">
                <div class="tip-icon">💵</div>
                <h4>ราคาแข่งขันได้</h4>
                <p>ตรวจสอบราคาตลาดให้เหมาะสมกับคุณภาพ</p>
            </div>

            <div class="tip-card">
                <div class="tip-icon">⭐</div>
                <h4>คุณภาพเป็นสำคัญ</h4>
                <p>เลือกอาหารที่มีคุณภาพดีเพื่อสุขภาพแมว</p>
            </div>
        </div>
    </div>
</body>

</html>