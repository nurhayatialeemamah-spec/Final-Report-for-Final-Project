<!-- 662061000 Nurhayati Aleemamah. -->

<?php
session_start();
require_once __DIR__ . '/../includes/db_connect.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

$booking_id = intval($_GET['id'] ?? 0);

if ($booking_id <= 0) {
    header("Location: admin.php?tab=bookings");
    exit();
}

// ดึงข้อมูลการจอง
$booking_query = "
    SELECT b.*, 
           u.user_id, u.username, u.email, u.phone, u.address,
           r.type AS room_type, r.size, r.price_per_day, r.price_per_hour,
           p.payment_id, p.amount AS paid_amount, p.status AS payment_status, 
           p.payment_date
    FROM bookings b
    JOIN user u ON b.user_id = u.user_id
    JOIN rooms r ON b.rooms_id = r.rooms_id
    LEFT JOIN payment p ON b.booking_id = p.booking_id
    WHERE b.booking_id = $booking_id
";

$booking_result = $conn->query($booking_query);

if ($booking_result->num_rows === 0) {
    echo "ไม่พบข้อมูลการจอง";
    exit();
}

$booking = $booking_result->fetch_assoc();

// ดึงข้อมูลแมวที่จอง
$cats_query = "
    SELECT c.cat_id, c.name, c.breed, c.age, c.weight, c.gender, c.disease, c.allergy
    FROM bookings_cats bc
    JOIN cats c ON bc.cat_id = c.cat_id
    WHERE bc.booking_id = $booking_id
";
$cats_result = $conn->query($cats_query);

// ดึงข้อมูลอาหารที่จอง (จากตาราง bookings_cats)
$foods_query = "
    SELECT bc.food, COUNT(*) as quantity
    FROM bookings_cats bc
    WHERE bc.booking_id = $booking_id AND bc.food IS NOT NULL AND bc.food != ''
    GROUP BY bc.food
";
$foods_result = $conn->query($foods_query);

// ประวัติการจองทั้งหมดของลูกค้าคนนี้
$history_query = "
    SELECT b.booking_id, b.start_date, b.end_date, b.total_price, b.status,
           r.type AS room_type
    FROM bookings b
    JOIN rooms r ON b.rooms_id = r.rooms_id
    WHERE b.user_id = {$booking['user_id']}
    ORDER BY b.created_at DESC
    LIMIT 10
";
$history_result = $conn->query($history_query);
?>
<!DOCTYPE html>
<html lang="th">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>รายละเอียดการจอง #<?= $booking_id ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/booking_detail.css">>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Bai+Jamjuree:wght@300;400;500;600&family=Cormorant+Garamond:wght@400;500;600;700&display=swap"
        rel="stylesheet">

</head>

<body>
    <div class="detail-container">
        <div class="detail-header">
            <div>
                <h1>การจอง #<?= $booking_id ?></h1>
                <span class="badge badge-<?= strtolower($booking['status']) ?>">
                    <?= $booking['status'] ?>
                </span>
            </div>
            <a href="admin.php?tab=bookings" class="btn">← กลับ</a>
        </div>

        <div class="detail-grid">
            <!-- ข้อมูลลูกค้า -->
            <div class="info-card">
                <h3>👤 ข้อมูลลูกค้า</h3>
                <div class="info-row">
                    <span class="info-label">ชื่อ:</span>
                    <span><?= htmlspecialchars($booking['username']) ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">อีเมล:</span>
                    <span><?= htmlspecialchars($booking['email']) ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">เบอร์โทร:</span>
                    <span><?= htmlspecialchars($booking['phone'] ?? '-') ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">ที่อยู่:</span>
                    <span><?= htmlspecialchars($booking['address'] ?? '-') ?></span>
                </div>
            </div>

            <!-- ข้อมูลห้องพัก -->
            <div class="info-card">
                <h3>🏠 ข้อมูลห้องพัก</h3>
                <div class="info-row">
                    <span class="info-label">ประเภทห้อง:</span>
                    <span><?= htmlspecialchars($booking['room_type']) ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">ขนาด:</span>
                    <span><?= htmlspecialchars($booking['size']) ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">ประเภทการจอง:</span>
                    <span><?= $booking['booking_type'] === 'daily' ? 'รายวัน' : 'รายชั่วโมง' ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">เริ่มต้น:</span>
                    <span><?= date('d/m/Y H:i', strtotime($booking['start_date'])) ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">สิ้นสุด:</span>
                    <span><?= date('d/m/Y H:i', strtotime($booking['end_date'])) ?></span>
                </div>
            </div>
        </div>

        <!-- แมวที่จอง -->
        <div class="info-card">
            <h3>🐱 แมวที่จอง</h3>
            <?php if ($cats_result->num_rows > 0): ?>
                <?php while ($cat = $cats_result->fetch_assoc()): ?>
                    <div class="cat-card">
                        <div class="cat-image"
                            style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); display: flex; align-items: center; justify-content: center; color: white; font-size: 2em;">
                            🐱
                        </div>
                        <div style="flex: 1;">
                            <strong style="font-size: 1.1em;"><?= htmlspecialchars($cat['name']) ?></strong>
                            <span
                                style="margin-left: 10px; padding: 2px 8px; background: #e0e7ff; border-radius: 4px; font-size: 0.85em;">
                                <?= htmlspecialchars($cat['gender']) ?>
                            </span>
                            <br>
                            <span class="text-muted" style="font-size: 0.9em;">
                                🏷️ พันธุ์: <?= htmlspecialchars($cat['breed']) ?> |
                                🎂 อายุ: <?= $cat['age'] ?> ปี |
                                ⚖️ น้ำหนัก: <?= $cat['weight'] ?> กก.
                            </span>
                            <?php if ($cat['disease']): ?>
                                <br>
                                <span style="color: #dc2626; font-size: 0.85em;">
                                    🏥 โรคประจำตัว: <?= htmlspecialchars($cat['disease']) ?>
                                </span>
                            <?php endif; ?>
                            <?php if ($cat['allergy']): ?>
                                <br>
                                <span style="color: #ea580c; font-size: 0.85em;">
                                    ⚠️ แพ้: <?= htmlspecialchars($cat['allergy']) ?>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p class="text-muted">ไม่มีข้อมูลแมว</p>
            <?php endif; ?>
        </div>

        <!-- อาหารที่จอง -->
        <?php if ($foods_result && $foods_result->num_rows > 0): ?>
            <div class="info-card">
                <h3>🍽️ อาหารที่จอง</h3>
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>ชื่อแมว</th>
                            <th>อาหารที่เลือก</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // ดึงข้อมูลแมวพร้อมอาหาร
                        $cats_foods_query = "
                            SELECT c.name, bc.food
                            FROM bookings_cats bc
                            JOIN cats c ON bc.cat_id = c.cat_id
                            WHERE bc.booking_id = $booking_id AND bc.food IS NOT NULL AND bc.food != ''
                        ";
                        $cats_foods_result = $conn->query($cats_foods_query);

                        while ($cf = $cats_foods_result->fetch_assoc()):
                            ?>
                            <tr>
                                <td><?= htmlspecialchars($cf['name']) ?></td>
                                <td><?= htmlspecialchars($cf['food']) ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>

        <!-- การชำระเงิน -->
        <div class="info-card">
            <h3>💰 การชำระเงิน</h3>
            <div class="info-row">
                <span class="info-label">ราคารวม:</span>
                <strong style="font-size: 1.2em; color: #10b981;">
                    <?= number_format($booking['total_price'], 2) ?> ฿
                </strong>
            </div>
            <div class="info-row">
                <span class="info-label">สถานะการชำระ:</span>
                <span class="badge badge-<?= strtolower($booking['payment_status'] ?? 'pending') ?>">
                    <?= $booking['payment_status'] ?? 'ยังไม่ชำระ' ?>
                </span>
            </div>
            <?php if ($booking['payment_date']): ?>
                <div class="info-row">
                    <span class="info-label">วันที่ชำระ:</span>
                    <span><?= date('d/m/Y H:i', strtotime($booking['payment_date'])) ?></span>
                </div>
            <?php endif; ?>
        </div>

        <!-- ประวัติการจองของลูกค้า -->
        <div class="info-card">
            <h3>📋 ประวัติการจองของลูกค้า</h3>
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>ห้อง</th>
                        <th>วันที่</th>
                        <th>ราคา</th>
                        <th>สถานะ</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($history = $history_result->fetch_assoc()): ?>
                        <tr <?= $history['booking_id'] == $booking_id ? 'style="background: #fef3c7;"' : '' ?>>
                            <td>#<?= $history['booking_id'] ?></td>
                            <td><?= htmlspecialchars($history['room_type']) ?></td>
                            <td>
                                <?= date('d/m/Y', strtotime($history['start_date'])) ?> -
                                <?= date('d/m/Y', strtotime($history['end_date'])) ?>
                            </td>
                            <td><?= number_format($history['total_price'], 2) ?> ฿</td>
                            <td>
                                <span class="badge badge-<?= strtolower($history['status']) ?>">
                                    <?= $history['status'] ?>
                                </span>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>

        <!-- ปุ่มจัดการ -->
        <div style="margin-top: 30px; display: flex; gap: 10px;">
            <?php if ($booking['status'] === 'Confirmed'): ?>
                <a href="booking_update.php?id=<?= $booking_id ?>&status=Occupied" class="btn primary"
                    onclick="return confirm('เปลี่ยนสถานะเป็น กำลังพัก?')">
                    ✅ เช็คอิน
                </a>
            <?php endif; ?>

            <?php if ($booking['status'] === 'Occupied'): ?>
                <a href="booking_update.php?id=<?= $booking_id ?>&status=Completed" class="btn success"
                    onclick="return confirm('เปลี่ยนสถานะเป็น เสร็จสิ้น?')">
                    🏁 เช็คเอาท์
                </a>
            <?php endif; ?>

            <?php if ($booking['status'] === 'Pending'): ?>
                <a href="booking_update.php?id=<?= $booking_id ?>&status=Cancelled" class="btn danger"
                    onclick="return confirm('ยกเลิกการจองนี้?')">
                    ❌ ยกเลิกการจอง
                </a>
            <?php endif; ?>
        </div>
    </div>
</body>

</html>