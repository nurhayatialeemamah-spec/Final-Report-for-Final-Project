<!-- 662061000 Nurhayati Aleemamah. -->


<?php
session_start();
require_once __DIR__ . '/../includes/db_connect.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

$room_id = intval($_GET['id'] ?? 0);
if (!$room_id) {
    header("Location: admin.php?tab=rooms");
    exit();
}

// ดึงข้อมูลห้อง
$stmt = $conn->prepare("SELECT * FROM rooms WHERE rooms_id=?");
$stmt->bind_param("i", $room_id);
$stmt->execute();
$room = $stmt->get_result()->fetch_assoc();

if (!$room) {
    header("Location: admin.php?tab=rooms");
    exit();
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $type = $conn->real_escape_string($_POST['type']);
    $size = $conn->real_escape_string($_POST['size']);
    $capacity = intval($_POST['capacity']);
    $max_cats = intval($_POST['max_cats']);
    $price_per_hour = floatval($_POST['price_per_hour']);
    $price_per_day = floatval($_POST['price_per_day']);
    $extra_cat_price = floatval($_POST['extra_cat_price'] ?? 0);
    $description = $conn->real_escape_string($_POST['description']);
    $status = $_POST['status'] ?? 'Available';

    if (empty($type) || $capacity <= 0 || $max_cats <= 0) {
        $error = "กรุณากรอกข้อมูลให้ครบถ้วน";
    } else {
        $sql = "UPDATE rooms SET 
                type='$type', size='$size', capacity=$capacity, max_cats=$max_cats,
                price_per_hour=$price_per_hour, price_per_day=$price_per_day, 
                extra_cat_price=$extra_cat_price, description='$description', status='$status'
                WHERE rooms_id=$room_id";

        if ($conn->query($sql)) {
            header("Location: admin.php?tab=rooms&success=updated");
            exit();
        } else {
            $error = "เกิดข้อผิดพลาด: " . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="th">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>แก้ไขห้องพัก #<?= $room_id ?> - Cat Hotel</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Bai+Jamjuree:wght@300;400;500;600;700;800;900&family=Cormorant+Garamond:wght@400;500;600;700&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/room_form.css">
</head>

<body>
    <div class="room-form-container">
        <!-- Back Button -->
        <div class="back-section">
            <a href="admin.php?tab=rooms" class="btn-back">
                <span class="icon">←</span>
                <span>กลับไปหน้าห้องพัก</span>
            </a>
        </div>

        <!-- Page Header -->
        <div class="page-header">
            <div class="header-icon">✏️</div>
            <div class="header-content">
                <h1>แก้ไขข้อมูลห้องพัก</h1>
                <p>อัปเดตข้อมูลห้องพัก #<?= $room_id ?> - <?= htmlspecialchars($room['type']) ?> Room</p>
            </div>
            <div class="header-decoration">🐱</div>
        </div>

        <!-- Error Alert -->
        <?php if ($error): ?>
            <div class="alert alert-error">
                <span class="alert-icon">⚠️</span>
                <div class="alert-content">
                    <strong>เกิดข้อผิดพลาด!</strong>
                    <p><?= $error ?></p>
                </div>
            </div>
        <?php endif; ?>

        <!-- Main Form -->
        <div class="form-card">
            <form method="POST">
                <!-- Basic Information Section -->
                <div class="form-section">
                    <div class="section-title">
                        <span class="title-icon">📋</span>
                        <h2>ข้อมูลพื้นฐาน</h2>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="type">
                                <span class="label-icon">🏷️</span>
                                <span class="label-text">ประเภทห้อง</span>
                                <span class="required">*</span>
                            </label>
                            <input type="text" id="type" name="type" placeholder="เช่น Standard, Deluxe, VIP"
                                value="<?= htmlspecialchars($room['type']) ?>" required>
                            <small class="help-text">ชื่อประเภทห้องพัก</small>
                        </div>

                        <div class="form-group">
                            <label for="size">
                                <span class="label-icon">📏</span>
                                <span class="label-text">ขนาดห้อง</span>
                                <span class="required">*</span>
                            </label>
                            <input type="text" id="size" name="size" placeholder="เช่น 3x3 m, 4x4 m"
                                value="<?= htmlspecialchars($room['size']) ?>" required>
                            <small class="help-text">ขนาดของห้องพัก</small>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="capacity">
                                <span class="label-icon">🏠</span>
                                <span class="label-text">จำนวนห้อง</span>
                                <span class="required">*</span>
                            </label>
                            <input type="number" id="capacity" name="capacity" min="1" placeholder="5"
                                value="<?= $room['capacity'] ?>" required>
                            <small class="help-text">จำนวนห้องทั้งหมดที่มี</small>
                        </div>

                        <div class="form-group">
                            <label for="max_cats">
                                <span class="label-icon">🐾</span>
                                <span class="label-text">รองรับแมวสูงสุด</span>
                                <span class="required">*</span>
                            </label>
                            <input type="number" id="max_cats" name="max_cats" min="1" placeholder="2"
                                value="<?= $room['max_cats'] ?>" required>
                            <small class="help-text">จำนวนแมวสูงสุดต่อห้อง</small>
                        </div>
                    </div>
                </div>

                <!-- Pricing Section -->
                <div class="form-section">
                    <div class="section-title">
                        <span class="title-icon">💰</span>
                        <h2>ราคาและค่าบริการ</h2>
                    </div>

                    <div class="form-row">
                        <div class="form-group highlight">
                            <label for="price_per_day">
                                <span class="label-icon">📅</span>
                                <span class="label-text">ราคาต่อวัน</span>
                                <span class="required">*</span>
                            </label>
                            <div class="input-with-unit">
                                <input type="number" id="price_per_day" name="price_per_day" step="0.01" min="0"
                                    placeholder="500.00" value="<?= $room['price_per_day'] ?>" required>
                                <span class="unit">บาท</span>
                            </div>
                            <small class="help-text">ราคาต่อคืน</small>
                        </div>

                        <div class="form-group highlight">
                            <label for="price_per_hour">
                                <span class="label-icon">⏰</span>
                                <span class="label-text">ราคาต่อชั่วโมง</span>
                            </label>
                            <div class="input-with-unit">
                                <input type="number" id="price_per_hour" name="price_per_hour" step="0.01" min="0"
                                    placeholder="100.00" value="<?= $room['price_per_hour'] ?>">
                                <span class="unit">บาท</span>
                            </div>
                            <small class="help-text">ราคาต่อชั่วโมง (ถ้ามี)</small>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="extra_cat_price">
                                <span class="label-icon">➕</span>
                                <span class="label-text">ราคาแมวเพิ่ม</span>
                            </label>
                            <div class="input-with-unit">
                                <input type="number" id="extra_cat_price" name="extra_cat_price" step="0.01" min="0"
                                    placeholder="50.00" value="<?= $room['extra_cat_price'] ?? 50 ?>">
                                <span class="unit">บาท</span>
                            </div>
                            <small class="help-text">ค่าธรรมเนียมแมวเพิ่มต่อตัว</small>
                        </div>

                        <div class="form-group">
                            <label for="status">
                                <span class="label-icon">🔔</span>
                                <span class="label-text">สถานะห้อง</span>
                            </label>
                            <select id="status" name="status">
                                <option value="Available" <?= $room['status'] === 'Available' ? 'selected' : '' ?>>
                                    ✅ พร้อมให้บริการ
                                </option>
                                <option value="Occupied" <?= $room['status'] === 'Occupied' ? 'selected' : '' ?>>
                                    ⛔ ไม่พร้อมให้บริการ
                                </option>
                            </select>
                            <small class="help-text">สถานะปัจจุบันของห้อง</small>
                        </div>
                    </div>
                </div>

                <!-- Description Section -->
                <div class="form-section">
                    <div class="section-title">
                        <span class="title-icon">📝</span>
                        <h2>รายละเอียดเพิ่มเติม</h2>
                    </div>

                    <div class="form-group full-width">
                        <label for="description">
                            <span class="label-icon">💬</span>
                            <span class="label-text">รายละเอียดห้อง</span>
                        </label>
                        <textarea id="description" name="description"
                            placeholder="รายละเอียดเพิ่มเติมเกี่ยวกับห้องพัก เช่น สิ่งอำนวยความสะดวก อุปกรณ์ภายในห้อง ฯลฯ"
                            rows="5"><?= htmlspecialchars($room['description']) ?></textarea>
                        <small class="help-text">คำอธิบายเกี่ยวกับห้องพักนี้</small>
                    </div>
                </div>

                <!-- Form Actions -->
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">
                        <span class="btn-icon">💾</span>
                        <span>บันทึกการแก้ไข</span>
                    </button>
                    <a href="admin.php?tab=rooms" class="btn btn-secondary">
                        <span class="btn-icon">❌</span>
                        <span>ยกเลิก</span>
                    </a>
                </div>
            </form>
        </div>

        <!-- Room Info Box -->
        <div class="info-box">
            <div class="info-icon">📊</div>
            <div class="info-content">
                <h3>ข้อมูลห้องปัจจุบัน</h3>
                <ul>
                    <li><strong>รหัสห้อง:</strong> #<?= $room_id ?></li>
                    <li><strong>ประเภท:</strong> <?= htmlspecialchars($room['type']) ?> Room</li>
                    <li><strong>สถานะ:</strong>
                        <?= $room['status'] === 'Available' ? '✅ พร้อมให้บริการ' : '⛔ ไม่พร้อมให้บริการ' ?></li>
                    <li><strong>อัปเดตล่าสุด:</strong> กำลังแก้ไข...</li>
                </ul>
            </div>
        </div>
    </div>
</body>

</html>