<!-- 662061000 Nurhayati Aleemamah. -->

<?php
require_once __DIR__ . '/../includes/db_connect.php';

// เพิ่ม/แก้ไข/ลบ ห้องพัก
if (isset($_POST['add'])) {
    $type = $_POST['type'];
    $size = $_POST['size'];
    $capacity = $_POST['capacity'];
    $price_per_hour = $_POST['price_per_hour'];
    $price_per_day = $_POST['price_per_day'];
    $image = $_POST['image'];
    $conn->query("INSERT INTO rooms (type,size,capacity,price_per_hour,price_per_day,image) VALUES ('$type','$size',$capacity,$price_per_hour,$price_per_day,'$image')");
}

if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $conn->query("DELETE FROM rooms WHERE rooms_id=$id");
}

$rooms = $conn->query("SELECT * FROM rooms");
?>

<h2>จัดการห้องพัก</h2>

<form method="POST">
    ชนิดห้อง: <input type="text" name="type" required>
    ขนาด: <input type="text" name="size">
    จำนวนคน/แมว: <input type="number" name="capacity">
    ราคา/ชั่วโมง: <input type="number" name="price_per_hour" step="0.01">
    ราคา/วัน: <input type="number" name="price_per_day" step="0.01">
    รูปภาพ: <input type="text" name="image">
    <button type="submit" name="add">เพิ่มห้อง</button>
</form>

<table border="1">
    <tr>
        <th>ID</th>
        <th>Type</th>
        <th>Size</th>
        <th>Capacity</th>
        <th>Price/Hour</th>
        <th>Price/Day</th>
        <th>Image</th>
        <th>Action</th>
    </tr>
    <?php while ($row = $rooms->fetch_assoc()): ?>
        <tr>
            <td><?php echo $row['rooms_id']; ?></td>
            <td><?php echo $row['type']; ?></td>
            <td><?php echo $row['size']; ?></td>
            <td><?php echo $row['capacity']; ?></td>
            <td><?php echo $row['price_per_hour']; ?></td>
            <td><?php echo $row['price_per_day']; ?></td>
            <td><?php echo $row['image']; ?></td>
            <td><a href="?delete=<?php echo $row['rooms_id']; ?>">ลบ</a></td>
        </tr>
    <?php endwhile; ?>
</table>