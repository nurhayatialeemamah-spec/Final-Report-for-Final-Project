<!-- 662061000 Nurhayati Aleemamah. -->

<?php
session_start();
require_once __DIR__ . '/includes/db_connect.php';$conn->set_charset('utf8mb4');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    $stmt = $conn->prepare('SELECT * FROM user WHERE email = ? LIMIT 1');
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $r = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($r && password_verify($password, $r['password'])) {
        $_SESSION['user_id'] = $r['user_id'];
        $_SESSION['name'] = $r['username'];
        $_SESSION['role'] = $r['role'];

        if ($r['role'] === 'admin' || $r['role'] === 'staff') {
            header('Location: admin/admin.php');
        } else {
            header('Location: index.php');
        }
        exit();
    } else {
        $error = 'อีเมลหรือรหัสผ่านไม่ถูกต้อง';
    }
}
?>
<!DOCTYPE html>
<html lang="th">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>เข้าสู่ระบบ - Cat Hotel</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/auth_overlay.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Bai+Jamjuree:wght@300;400;500;600&family=Cormorant+Garamond:wght@400;500;600;700&display=swap"
        rel="stylesheet">

    <style>
        * {
            font-family: 'Bai Jamjuree', 'Cormorant Garamond', serif;
        }
    </style>

<body
    style="background: linear-gradient(135deg, #fff5ed 0%, #ffe4cc 100%); min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 20px;">

    <div class="auth-card" style="animation: slideUp 0.6s cubic-bezier(0.34, 1.56, 0.64, 1);">
        <a href="index.php" class="auth-close" style="position: absolute; top: 20px; right: 20px;">&times;</a>

        <!-- Decorative Paw Prints -->
        <span class="paw-print paw-print-1">🐾</span>
        <span class="paw-print paw-print-2">🐾</span>

        <div class="auth-header">
            <div class="auth-cat-icon">😺</div>
            <h2>เข้าสู่ระบบ</h2>
            <p>ยินดีต้อนรับกลับมา</p>
        </div>

        <?php if (isset($error)): ?>
            <div class="form-message error">
                <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>

        <form method="POST" class="auth-form">
            <div class="form-group">
                <label for="email">อีเมล</label>
                <span class="input-icon">📧</span>
                <input type="email" id="email" name="email" required placeholder="กรอกอีเมลของคุณ"
                    value="<?= isset($_POST['email']) ? htmlspecialchars($_POST['email']) : '' ?>">
            </div>

            <div class="form-group">
                <label for="password">รหัสผ่าน</label>
                <span class="input-icon">🔒</span>
                <input type="password" id="password" name="password" required placeholder="กรอกรหัสผ่าน">
            </div>

            <button type="submit" class="btn-submit">🐱 เข้าสู่ระบบ</button>
        </form>

        <div class="auth-footer">
            <p>ยังไม่มีบัญชี? <a href="register.php">สมัครสมาชิก</a></p>
            <p style="margin-top: 10px;"><a href="index.php" style="color: #999;">← กลับหน้าหลัก</a></p>
        </div>
    </div>

</body>

</html>