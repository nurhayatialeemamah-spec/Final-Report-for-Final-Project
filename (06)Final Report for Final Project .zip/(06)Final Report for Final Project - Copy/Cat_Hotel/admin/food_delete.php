<!-- 662061000 Nurhayati Aleemamah. -->

<?php
session_start();
require_once __DIR__ . '/../includes/db_connect.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

if (isset($_GET['id'])) {
    $food_id = intval($_GET['id']);

    // ตรวจสอบว่ามีการใช้อาหารนี้ในการจองหรือไม่
    $check = $conn->query("SELECT COUNT(*) as cnt FROM bookings_cats WHERE food = (SELECT foods_name FROM foods WHERE foods_id = $food_id)");
    $result = $check->fetch_assoc();

    if ($result['cnt'] > 0) {
        // มีการใช้งานอยู่ ไม่สามารถลบได้
        header("Location: admin.php?tab=foods&error=in_use");
        exit();
    }

    // ลบอาหาร
    if ($conn->query("DELETE FROM foods WHERE foods_id = $food_id")) {
        header("Location: admin.php?tab=foods&success=deleted");
        exit();
    } else {
        header("Location: admin.php?tab=foods&error=delete_failed");
        exit();
    }
} else {
    header("Location: admin.php?tab=foods");
    exit();
}
?>