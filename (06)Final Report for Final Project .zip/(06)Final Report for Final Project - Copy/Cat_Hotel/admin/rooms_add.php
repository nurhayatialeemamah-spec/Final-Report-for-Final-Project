<!-- 662061000 Nurhayati Aleemamah. -->

<?php
session_start();
require_once __DIR__ . '/../includes/db_connect.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $type = $conn->real_escape_string($_POST['type']);
    $size = $conn->real_escape_string($_POST['size']);
    $capacity = intval($_POST['capacity']);
    $max_cats = intval($_POST['max_cats']);
    $price_per_hour = floatval($_POST['price_per_hour']);
    $price_per_day = floatval($_POST['price_per_day']);
    $description = $conn->real_escape_string($_POST['description']);

    if (empty($type) || $capacity <= 0 || $max_cats <= 0) {
        $error = "กรุณากรอกข้อมูลให้ครบถ้วน";
    } else {
        $sql = "INSERT INTO rooms (type, size, capacity, max_cats, price_per_hour, price_per_day, description, status) 
                VALUES ('$type', '$size', $capacity, $max_cats, $price_per_hour, $price_per_day, '$description', 'Available')";

        if ($conn->query($sql)) {
            header("Location: admin.php?tab=rooms&success=added");
            exit();
        } else {
            $error = "เกิดข้อผิดพลาด: " . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="th">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>เพิ่มห้องพักใหม่</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Bai+Jamjuree:wght@300;400;500;600&family=Cormorant+Garamond:wght@400;500;600;700&display=swap"
        rel="stylesheet">
</head>

<body>
    <div class="user-detail-container">
        <div class="back-button">
            <a href="admin.php?tab=rooms" class="btn">← กลับ</a>
        </div>

        <div class="content-card">
            <h2>เพิ่มห้องพักใหม่</h2>

            <?php if ($error): ?>
                <div class="alert err"><?= $error ?></div>
            <?php endif; ?>

            <form method="POST">
                <label>ประเภทห้อง *</label>
                <input type="text" name="type" placeholder="เช่น Standard, Deluxe, Suite, Luxury" required>

                <label>ขนาดห้อง</label>
                <input type="text" name="size" placeholder="เช่น 3x3 ม." value="3x3 ม.">

                <label>จำนวนห้อง (Capacity) *</label>
                <input type="number" name="capacity" min="1" value="2" required>
                <small class="muted">จำนวนห้องประเภทนี้ที่มีทั้งหมด</small>

                <label>รองรับแมวสูงสุด (ต่อห้อง) *</label>
                <input type="number" name="max_cats" min="1" value="2" required>
                <small class="muted">จำนวนแมวสูงสุดที่พักในห้องเดียวได้</small>

                <label>ราคาต่อชั่วโมง (บาท) *</label>
                <input type="number" step="0.01" name="price_per_hour" min="0" value="100" required>

                <label>ราคาต่อวัน (บาท) *</label>
                <input type="number" step="0.01" name="price_per_day" min="0" value="500" required>

                <label>รายละเอียด</label>
                <textarea name="description" rows="3" placeholder="รายละเอียดเพิ่มเติมของห้อง"></textarea>

                <div style="margin-top: 20px;">
                    <button type="submit" class="btn primary">บันทึก</button>
                    <a href="admin.php?tab=rooms" class="btn">ยกเลิก</a>
                </div>
            </form>
        </div>
    </div>
</body>

</html>