<!-- 662061000 Nurhayati Aleemamah. -->

<?php
session_start();
require_once __DIR__ . '/../includes/db_connect.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

$user_id = intval($_GET['user_id'] ?? 0);
if (!$user_id) {
    echo "ไม่พบลูกค้า";
    exit;
}

// ดึงข้อมูลลูกค้า
$stmt = $conn->prepare("SELECT * FROM user WHERE user_id=?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user_detail = $stmt->get_result()->fetch_assoc();

if (!$user_detail) {
    echo "ไม่พบข้อมูลลูกค้า";
    exit;
}

// ดึงข้อมูลแมวของลูกค้า
$cats_stmt = $conn->prepare("SELECT * FROM cats WHERE user_id=?");
$cats_stmt->bind_param("i", $user_id);
$cats_stmt->execute();
$cats = $cats_stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// ดึงรายการจองพร้อมรายละเอียด
$bookings_stmt = $conn->prepare("
    SELECT b.booking_id, r.type AS room_type, r.rooms_id,
           b.start_date, b.end_date, b.booking_type, b.total_price, b.status,
           IFNULL(SUM(p.amount), 0) AS paid_amount,
           COUNT(DISTINCT bc.cat_id) AS cat_count
    FROM bookings b
    JOIN rooms r ON b.rooms_id = r.rooms_id
    LEFT JOIN payment p ON b.booking_id = p.booking_id AND p.status='Paid'
    LEFT JOIN bookings_cats bc ON b.booking_id = bc.booking_id
    WHERE b.user_id=?
    GROUP BY b.booking_id
    ORDER BY b.start_date DESC
");
$bookings_stmt->bind_param("i", $user_id);
$bookings_stmt->execute();
$bookings = $bookings_stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// คำนวณสถิติ
$total_bookings = count($bookings);
$total_spent = array_sum(array_column($bookings, 'paid_amount'));
$completed_bookings = count(array_filter($bookings, fn($b) => $b['status'] === 'Completed'));
?>
<!DOCTYPE html>
<html lang="th">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>รายละเอียดลูกค้า - <?= htmlspecialchars($user_detail['username']) ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Bai+Jamjuree:wght@300;400;500;600;700;800;900&family=Cormorant+Garamond:wght@400;500;600;700&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/user_detail.css">
</head>

<body>
    <div class="user-detail-container">
        <!-- Back Button -->
        <div class="back-button">
            <a href="admin.php?tab=customers" class="btn btn-back">
                <span class="icon">←</span>
                <span>กลับไปหน้า Admin</span>
            </a>
        </div>

        <!-- User Header -->
        <div class="user-header">
            <div class="header-content">
                <div class="user-avatar">
                    <span class="avatar-icon">👤</span>
                </div>
                <div class="user-title">
                    <h1><?= htmlspecialchars($user_detail['username']) ?></h1>
                    <p class="user-email"><?= htmlspecialchars($user_detail['email']) ?></p>
                </div>
            </div>
            <div class="header-decoration">🐱</div>
        </div>

        <!-- Stats Cards -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon">📞</div>
                <div class="stat-content">
                    <div class="stat-label">เบอร์โทรศัพท์</div>
                    <div class="stat-value"><?= htmlspecialchars($user_detail['phone'] ?? '-') ?></div>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-icon">👑</div>
                <div class="stat-content">
                    <div class="stat-label">บทบาท</div>
                    <div class="stat-value"><?= htmlspecialchars($user_detail['role'] ?? 'user') ?></div>
                </div>
            </div>

            <div class="stat-card highlight">
                <div class="stat-icon">📅</div>
                <div class="stat-content">
                    <div class="stat-label">จำนวนการจอง</div>
                    <div class="stat-value"><?= $total_bookings ?> ครั้ง</div>
                </div>
            </div>

            <div class="stat-card highlight">
                <div class="stat-icon">💰</div>
                <div class="stat-content">
                    <div class="stat-label">ยอดใช้จ่ายทั้งหมด</div>
                    <div class="stat-value"><?= number_format($total_spent, 2) ?> ฿</div>
                </div>
            </div>
        </div>

        <!-- Address Section -->
        <?php if (!empty($user_detail['address'])): ?>
            <div class="content-section">
                <div class="section-header">
                    <h2>📍 ที่อยู่</h2>
                </div>
                <div class="address-box">
                    <p><?= nl2br(htmlspecialchars($user_detail['address'])) ?></p>
                </div>
            </div>
        <?php endif; ?>

        <!-- Cats Section -->
        <div class="content-section">
            <div class="section-header">
                <h2>🐱 แมวของลูกค้า</h2>
                <span class="badge-count"><?= count($cats) ?> ตัว</span>
            </div>

            <?php if (count($cats) > 0): ?>
                <div class="cats-grid">
                    <?php foreach ($cats as $cat): ?>
                        <div class="cat-card">
                            <div class="cat-header">
                                <h3>🐾 <?= htmlspecialchars($cat['name']) ?></h3>
                                <span class="cat-gender <?= strtolower($cat['gender']) ?>">
                                    <?= $cat['gender'] === 'Male' ? '♂ ผู้' : '♀ เมีย' ?>
                                </span>
                            </div>

                            <div class="cat-details">
                                <div class="cat-detail-row">
                                    <span class="detail-icon">🎂</span>
                                    <span class="detail-label">อายุ</span>
                                    <span class="detail-value"><?= $cat['age'] ?> ปี</span>
                                </div>

                                <div class="cat-detail-row">
                                    <span class="detail-icon">🦁</span>
                                    <span class="detail-label">พันธุ์</span>
                                    <span class="detail-value"><?= htmlspecialchars($cat['breed']) ?></span>
                                </div>

                                <div class="cat-detail-row">
                                    <span class="detail-icon">⚖️</span>
                                    <span class="detail-label">น้ำหนัก</span>
                                    <span class="detail-value"><?= $cat['weight'] ?> กก.</span>
                                </div>

                                <?php if ($cat['disease']): ?>
                                    <div class="cat-detail-row warning">
                                        <span class="detail-icon">🏥</span>
                                        <span class="detail-label">โรคประจำตัว</span>
                                        <span class="detail-value"><?= htmlspecialchars($cat['disease']) ?></span>
                                    </div>
                                <?php endif; ?>

                                <?php if ($cat['allergy']): ?>
                                    <div class="cat-detail-row warning">
                                        <span class="detail-icon">⚠️</span>
                                        <span class="detail-label">แพ้อาหาร</span>
                                        <span class="detail-value"><?= htmlspecialchars($cat['allergy']) ?></span>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <span class="empty-icon">😿</span>
                    <p>ยังไม่มีข้อมูลแมว</p>
                </div>
            <?php endif; ?>
        </div>

        <!-- Bookings Timeline -->
        <div class="content-section">
            <div class="section-header">
                <h2>📅 ประวัติการจอง</h2>
                <span class="badge-count"><?= $total_bookings ?> ครั้ง</span>
            </div>

            <?php if (count($bookings) > 0): ?>
                <div class="booking-timeline">
                    <?php foreach ($bookings as $booking):
                        $num_days = max(1, ceil((strtotime($booking['end_date']) - strtotime($booking['start_date'])) / 86400));
                        ?>
                        <div class="booking-card">
                            <div class="booking-marker"></div>

                            <div class="booking-header">
                                <div class="booking-id">
                                    <span class="id-icon">🎫</span>
                                    <span class="id-text">Booking #<?= $booking['booking_id'] ?></span>
                                </div>
                                <span class="booking-status status-<?= strtolower($booking['status']) ?>">
                                    <?= $booking['status'] ?>
                                </span>
                            </div>

                            <div class="booking-info-grid">
                                <div class="booking-info">
                                    <span class="info-icon">🏠</span>
                                    <div>
                                        <div class="info-label">ห้อง</div>
                                        <div class="info-value"><?= htmlspecialchars($booking['room_type']) ?> Room</div>
                                    </div>
                                </div>

                                <div class="booking-info">
                                    <span class="info-icon">📆</span>
                                    <div>
                                        <div class="info-label">วันที่เข้าพัก</div>
                                        <div class="info-value"><?= date('d/m/Y', strtotime($booking['start_date'])) ?></div>
                                    </div>
                                </div>

                                <div class="booking-info">
                                    <span class="info-icon">📆</span>
                                    <div>
                                        <div class="info-label">วันที่คืนห้อง</div>
                                        <div class="info-value"><?= date('d/m/Y', strtotime($booking['end_date'])) ?></div>
                                    </div>
                                </div>

                                <div class="booking-info">
                                    <span class="info-icon">⏱️</span>
                                    <div>
                                        <div class="info-label">ระยะเวลา</div>
                                        <div class="info-value"><?= $num_days ?> วัน</div>
                                    </div>
                                </div>

                                <div class="booking-info">
                                    <span class="info-icon">🐱</span>
                                    <div>
                                        <div class="info-label">จำนวนแมว</div>
                                        <div class="info-value"><?= $booking['cat_count'] ?> ตัว</div>
                                    </div>
                                </div>

                                <div class="booking-info">
                                    <span class="info-icon">📋</span>
                                    <div>
                                        <div class="info-label">ประเภท</div>
                                        <div class="info-value">
                                            <?= $booking['booking_type'] === 'Daily' ? 'รายวัน' : 'รายชั่วโมง' ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="booking-info price">
                                    <span class="info-icon">💵</span>
                                    <div>
                                        <div class="info-label">ราคารวม</div>
                                        <div class="info-value"><?= number_format($booking['total_price'], 2) ?> ฿</div>
                                    </div>
                                </div>

                                <div class="booking-info paid">
                                    <span class="info-icon">✅</span>
                                    <div>
                                        <div class="info-label">ยอดชำระแล้ว</div>
                                        <div class="info-value"><?= number_format($booking['paid_amount'], 2) ?> ฿</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <span class="empty-icon">📭</span>
                    <p>ยังไม่มีการจอง</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>

</html>