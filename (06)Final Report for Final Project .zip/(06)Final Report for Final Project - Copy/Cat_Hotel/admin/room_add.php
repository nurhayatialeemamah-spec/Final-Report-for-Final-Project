<!-- 662061000 Nurhayati Aleemamah. -->

<?php
session_start();
require_once __DIR__ . '/../includes/db_connect.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

$error = '';
$success = '';

// ถ้ามี ID แสดงว่าเป็นการแก้ไข
$edit_mode = false;
$room = null;

if (isset($_GET['id'])) {
    $edit_mode = true;
    $room_id = intval($_GET['id']);
    $result = $conn->query("SELECT * FROM rooms WHERE rooms_id = $room_id");
    $room = $result->fetch_assoc();

    if (!$room) {
        header("Location: admin.php?tab=rooms");
        exit();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $type = $conn->real_escape_string($_POST['type']);
    $size = $conn->real_escape_string($_POST['size']);
    $capacity = intval($_POST['capacity']);
    $max_cats = intval($_POST['max_cats']);
    $price_per_day = floatval($_POST['price_per_day']);
    $price_per_hour = floatval($_POST['price_per_hour']);
    $extra_cat_price = floatval($_POST['extra_cat_price']);
    $description = $conn->real_escape_string($_POST['description']);
    $status = $_POST['status'] ?? 'Available';

    // Validation
    if (empty($type)) {
        $error = "กรุณาระบุประเภทห้อง";
    } elseif (empty($size)) {
        $error = "กรุณาระบุขนาดห้อง";
    } elseif ($capacity <= 0) {
        $error = "กรุณาระบุจำนวนห้องที่ถูกต้อง";
    } elseif ($max_cats <= 0) {
        $error = "กรุณาระบุจำนวนแมวสูงสุดที่ถูกต้อง";
    } elseif ($price_per_day <= 0) {
        $error = "กรุณาระบุราคาต่อวันที่ถูกต้อง";
    } else {
        if ($edit_mode) {
            // อัปเดตข้อมูล
            $sql = "UPDATE rooms SET 
                    type = '$type',
                    size = '$size',
                    capacity = $capacity,
                    max_cats = $max_cats,
                    price_per_day = $price_per_day,
                    price_per_hour = $price_per_hour,
                    extra_cat_price = $extra_cat_price,
                    description = '$description',
                    status = '$status'
                    WHERE rooms_id = $room_id";

            if ($conn->query($sql)) {
                header("Location: admin.php?tab=rooms&success=updated");
                exit();
            } else {
                $error = "เกิดข้อผิดพลาด: " . $conn->error;
            }
        } else {
            // เพิ่มข้อมูลใหม่
            $image = 'room-default.jpg'; // รูปภาพเริ่มต้น

            $sql = "INSERT INTO rooms (type, size, capacity, max_cats, price_per_day, price_per_hour, 
                    extra_cat_price, description, image, status) 
                    VALUES ('$type', '$size', $capacity, $max_cats, $price_per_day, $price_per_hour, 
                    $extra_cat_price, '$description', '$image', '$status')";

            if ($conn->query($sql)) {
                header("Location: admin.php?tab=rooms&success=added");
                exit();
            } else {
                $error = "เกิดข้อผิดพลาด: " . $conn->error;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="th">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $edit_mode ? 'แก้ไขห้องพัก' : 'เพิ่มห้องพักใหม่' ?> - Cat Hotel</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Bai+Jamjuree:wght@300;400;500;600;700;800;900&family=Cormorant+Garamond:wght@400;500;600;700&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/room_form.css">
</head>

<body>
    <div class="room-form-container">
        <!-- Back Button -->
        <div class="back-section">
            <a href="admin.php?tab=rooms" class="btn-back">
                <span class="icon">←</span>
                <span>กลับไปหน้าห้องพัก</span>
            </a>
        </div>

        <!-- Page Header -->
        <div class="page-header">
            <div class="header-icon"><?= $edit_mode ? '✏️' : '🏠' ?></div>
            <div class="header-content">
                <h1><?= $edit_mode ? 'แก้ไขข้อมูลห้องพัก' : 'เพิ่มห้องพักใหม่' ?></h1>
                <p><?= $edit_mode ? 'อัปเดตข้อมูลห้องพัก #' . $room_id : 'กรอกข้อมูลห้องพักที่ต้องการเพิ่มใหม่' ?></p>
            </div>
            <div class="header-decoration">🐱</div>
        </div>

        <!-- Error Alert -->
        <?php if ($error): ?>
            <div class="alert alert-error">
                <span class="alert-icon">⚠️</span>
                <div class="alert-content">
                    <strong>เกิดข้อผิดพลาด!</strong>
                    <p><?= $error ?></p>
                </div>
            </div>
        <?php endif; ?>

        <!-- Main Form -->
        <div class="form-card">
            <form method="POST">
                <!-- Basic Information Section -->
                <div class="form-section">
                    <div class="section-title">
                        <span class="title-icon">📋</span>
                        <h2>ข้อมูลพื้นฐาน</h2>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="type">
                                <span class="label-icon">🏷️</span>
                                <span class="label-text">ประเภทห้อง</span>
                                <span class="required">*</span>
                            </label>
                            <input type="text" id="type" name="type" placeholder="เช่น Standard, Deluxe, VIP"
                                value="<?= $edit_mode ? htmlspecialchars($room['type']) : '' ?>" required>
                            <small class="help-text">ชื่อประเภทห้องพัก</small>
                        </div>

                        <div class="form-group">
                            <label for="size">
                                <span class="label-icon">📏</span>
                                <span class="label-text">ขนาดห้อง</span>
                                <span class="required">*</span>
                            </label>
                            <input type="text" id="size" name="size" placeholder="เช่น 3x3 m, 4x4 m"
                                value="<?= $edit_mode ? htmlspecialchars($room['size']) : '' ?>" required>
                            <small class="help-text">ขนาดของห้องพัก</small>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="capacity">
                                <span class="label-icon">🏠</span>
                                <span class="label-text">จำนวนห้อง</span>
                                <span class="required">*</span>
                            </label>
                            <input type="number" id="capacity" name="capacity" min="1" placeholder="5"
                                value="<?= $edit_mode ? $room['capacity'] : '' ?>" required>
                            <small class="help-text">จำนวนห้องทั้งหมดที่มี</small>
                        </div>

                        <div class="form-group">
                            <label for="max_cats">
                                <span class="label-icon">🐾</span>
                                <span class="label-text">รองรับแมวสูงสุด</span>
                                <span class="required">*</span>
                            </label>
                            <input type="number" id="max_cats" name="max_cats" min="1" placeholder="2"
                                value="<?= $edit_mode ? $room['max_cats'] : '' ?>" required>
                            <small class="help-text">จำนวนแมวสูงสุดต่อห้อง</small>
                        </div>
                    </div>
                </div>

                <!-- Pricing Section -->
                <div class="form-section">
                    <div class="section-title">
                        <span class="title-icon">💰</span>
                        <h2>ราคาและค่าบริการ</h2>
                    </div>

                    <div class="form-row">
                        <div class="form-group highlight">
                            <label for="price_per_day">
                                <span class="label-icon">📅</span>
                                <span class="label-text">ราคาต่อวัน</span>
                                <span class="required">*</span>
                            </label>
                            <div class="input-with-unit">
                                <input type="number" id="price_per_day" name="price_per_day" step="0.01" min="0"
                                    placeholder="500.00" value="<?= $edit_mode ? $room['price_per_day'] : '' ?>"
                                    required>
                                <span class="unit">บาท</span>
                            </div>
                            <small class="help-text">ราคาต่อคืน</small>
                        </div>

                        <div class="form-group highlight">
                            <label for="price_per_hour">
                                <span class="label-icon">⏰</span>
                                <span class="label-text">ราคาต่อชั่วโมง</span>
                            </label>
                            <div class="input-with-unit">
                                <input type="number" id="price_per_hour" name="price_per_hour" step="0.01" min="0"
                                    placeholder="100.00" value="<?= $edit_mode ? $room['price_per_hour'] : '' ?>">
                                <span class="unit">บาท</span>
                            </div>
                            <small class="help-text">ราคาต่อชั่วโมง (ถ้ามี)</small>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="extra_cat_price">
                                <span class="label-icon">➕</span>
                                <span class="label-text">ราคาแมวเพิ่ม</span>
                            </label>
                            <div class="input-with-unit">
                                <input type="number" id="extra_cat_price" name="extra_cat_price" step="0.01" min="0"
                                    placeholder="50.00" value="<?= $edit_mode ? $room['extra_cat_price'] : '50' ?>">
                                <span class="unit">บาท</span>
                            </div>
                            <small class="help-text">ค่าธรรมเนียมแมวเพิ่มต่อตัว</small>
                        </div>

                        <div class="form-group">
                            <label for="status">
                                <span class="label-icon">🔔</span>
                                <span class="label-text">สถานะห้อง</span>
                            </label>
                            <select id="status" name="status">
                                <option value="Available" <?= ($edit_mode && $room['status'] === 'Available') ? 'selected' : '' ?>>
                                    ✅ พร้อมให้บริการ
                                </option>
                                <option value="Occupied" <?= ($edit_mode && $room['status'] === 'Occupied') ? 'selected' : '' ?>>
                                    ⛔ ไม่พร้อมให้บริการ
                                </option>
                            </select>
                            <small class="help-text">สถานะปัจจุบันของห้อง</small>
                        </div>
                    </div>
                </div>

                <!-- Description Section -->
                <div class="form-section">
                    <div class="section-title">
                        <span class="title-icon">📝</span>
                        <h2>รายละเอียดเพิ่มเติม</h2>
                    </div>

                    <div class="form-group full-width">
                        <label for="description">
                            <span class="label-icon">💬</span>
                            <span class="label-text">รายละเอียดห้อง</span>
                        </label>
                        <textarea id="description" name="description"
                            placeholder="รายละเอียดเพิ่มเติมเกี่ยวกับห้องพัก เช่น สิ่งอำนวยความสะดวก อุปกรณ์ภายในห้อง ฯลฯ"
                            rows="5"><?= $edit_mode ? htmlspecialchars($room['description']) : '' ?></textarea>
                        <small class="help-text">คำอธิบายเกี่ยวกับห้องพักนี้</small>
                    </div>
                </div>

                <!-- Form Actions -->
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">
                        <span class="btn-icon"><?= $edit_mode ? '💾' : '➕' ?></span>
                        <span><?= $edit_mode ? 'บันทึกการแก้ไข' : 'เพิ่มห้องพัก' ?></span>
                    </button>
                    <a href="admin.php?tab=rooms" class="btn btn-secondary">
                        <span class="btn-icon">❌</span>
                        <span>ยกเลิก</span>
                    </a>
                </div>
            </form>
        </div>

        <!-- Info Box -->
        <div class="info-box">
            <div class="info-icon">💡</div>
            <div class="info-content">
                <h3>ข้อมูลที่ควรทราบ</h3>
                <ul>
                    <li><strong>ประเภทห้อง:</strong> ใช้ชื่อที่เข้าใจง่าย เช่น Standard, Deluxe, VIP</li>
                    <li><strong>ขนาดห้อง:</strong> ระบุขนาดเป็นเมตร เช่น 3x3 m, 4x4 m</li>
                    <li><strong>ราคา:</strong> ระบุเป็นบาท สามารถมีทศนิยมได้</li>
                    <li><strong>แมวเพิ่ม:</strong> ค่าธรรมเนียมสำหรับแมวตัวที่เกินจำนวนมาตรฐาน</li>
                </ul>
            </div>
        </div>
    </div>
</body>

</html>