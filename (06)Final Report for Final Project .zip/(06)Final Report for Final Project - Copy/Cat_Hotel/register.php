<!-- 662061000 Nurhayati Aleemamah. -->

<?php
session_start();
require_once __DIR__ . '/includes/db_connect.php';
$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username'] ?? '');
    $surname = trim($_POST['surname'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $password = $_POST['password'] ?? '';
    $role = "user";

    // Validation
    if (empty($username) || empty($surname) || empty($email) || empty($password)) {
        $error = 'กรุณากรอกข้อมูลที่จำเป็นให้ครบถ้วน';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'รูปแบบอีเมลไม่ถูกต้อง';
    } elseif (strlen($password) < 6) {
        $error = 'รหัสผ่านต้องมีอย่างน้อย 6 ตัวอักษร';
    } else {
        // ตรวจสอบอีเมลซ้ำ
        $checkStmt = $conn->prepare("SELECT user_id FROM user WHERE email = ?");
        $checkStmt->bind_param("s", $email);
        $checkStmt->execute();
        $checkResult = $checkStmt->get_result();

        if ($checkResult->num_rows > 0) {
            $error = 'อีเมลนี้ถูกใช้งานแล้ว';
            $checkStmt->close();
        } else {
            $checkStmt->close();

            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO user (username, surname, email, phone, address, password, role, created_at)
                                    VALUES (?, ?, ?, ?, ?, ?, ?, NOW())");
            $stmt->bind_param("sssssss", $username, $surname, $email, $phone, $address, $hashedPassword, $role);

            if ($stmt->execute()) {
                $_SESSION['user_id'] = $stmt->insert_id;
                $_SESSION['name'] = $username;
                $_SESSION['role'] = $role;

                $stmt->close();
                header('Location: index.php');
                exit();
            } else {
                $error = 'เกิดข้อผิดพลาด: ' . $stmt->error;
                $stmt->close();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="th">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>สมัครสมาชิก - Cat Hotel</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/auth_overlay.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Bai+Jamjuree:wght@300;400;500;600&family=Cormorant+Garamond:wght@400;500;600;700&display=swap"
        rel="stylesheet">

    <style>
        * {
            font-family: 'Bai Jamjuree', 'Cormorant Garamond', serif;
        }
    </style>
</head>

<body
    style="background: linear-gradient(135deg, #fff5ed 0%, #ffe4cc 100%); min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 20px;">

    <div class="auth-card" style="animation: slideUp 0.6s cubic-bezier(0.34, 1.56, 0.64, 1);">
        <a href="index.php" class="auth-close" style="position: absolute; top: 20px; right: 20px;">&times;</a>

        <!-- Decorative Paw Prints -->
        <span class="paw-print paw-print-1">🐾</span>
        <span class="paw-print paw-print-2">🐾</span>
        <span class="paw-print paw-print-3">🐾</span>

        <div class="auth-header">
            <div class="auth-cat-icon">🐱</div>
            <h2>สมัครสมาชิก</h2>
            <p>เริ่มต้นใช้งาน Cat Hotel</p>
        </div>

        <?php if ($error): ?>
            <div class="form-message error">
                <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>

        <form method="POST" class="auth-form">
            <div class="form-row">
                <div class="form-group">
                    <label for="username">ชื่อ *</label>
                    <span class="input-icon">👤</span>
                    <input type="text" id="username" name="username" required placeholder="ชื่อของคุณ"
                        value="<?= isset($_POST['username']) ? htmlspecialchars($_POST['username']) : '' ?>">
                </div>

                <div class="form-group">
                    <label for="surname">นามสกุล *</label>
                    <span class="input-icon">👤</span>
                    <input type="text" id="surname" name="surname" required placeholder="นามสกุล"
                        value="<?= isset($_POST['surname']) ? htmlspecialchars($_POST['surname']) : '' ?>">
                </div>
            </div>

            <div class="form-group">
                <label for="email">อีเมล *</label>
                <span class="input-icon">📧</span>
                <input type="email" id="email" name="email" required placeholder="อีเมลของคุณ"
                    value="<?= isset($_POST['email']) ? htmlspecialchars($_POST['email']) : '' ?>">
            </div>

            <div class="form-group">
                <label for="phone">เบอร์โทรศัพท์</label>
                <span class="input-icon">📱</span>
                <input type="tel" id="phone" name="phone" placeholder="098-xxx-xxxx" pattern="[0-9]{10}"
                    value="<?= isset($_POST['phone']) ? htmlspecialchars($_POST['phone']) : '' ?>">
            </div>

            <div class="form-group">
                <label for="password">รหัสผ่าน *</label>
                <span class="input-icon">🔒</span>
                <input type="password" id="password" name="password" required
                    placeholder="สร้างรหัสผ่าน (อย่างน้อย 6 ตัวอักษร)" minlength="6">
            </div>

            <div class="form-group">
                <label for="address">ที่อยู่ (ถ้ามี)</label>
                <textarea id="address" name="address" rows="3"
                    placeholder="ที่อยู่สำหรับการจัดส่ง"><?= isset($_POST['address']) ? htmlspecialchars($_POST['address']) : '' ?></textarea>
            </div>

            <button type="submit" class="btn-submit">🐱 สมัครสมาชิก</button>
        </form>

        <div class="auth-footer">
            <p>มีบัญชีอยู่แล้ว? <a href="login.php">เข้าสู่ระบบ</a></p>
            <p style="margin-top: 10px;"><a href="index.php" style="color: #999;">← กลับหน้าหลัก</a></p>
        </div>
    </div>

</body>

</html>